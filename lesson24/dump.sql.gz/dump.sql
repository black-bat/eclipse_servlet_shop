--
-- PostgreSQL database dump
--

-- Dumped from database version 13.8
-- Dumped by pg_dump version 13.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: informations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.informations (
    id integer NOT NULL,
    title character(35),
    count integer,
    total_price double precision,
    info_order character(100)
);


ALTER TABLE public.informations OWNER TO postgres;

--
-- Name: informations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.informations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.informations_id_seq OWNER TO postgres;

--
-- Name: informations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.informations_id_seq OWNED BY public.informations.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    date date,
    user_login character(50),
    info_order character(100),
    status character(25)
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    title character(35),
    price double precision,
    info character(30),
    info_picture character(30)
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: shopping_cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shopping_cart (
    id integer NOT NULL,
    product_id integer,
    count integer
);


ALTER TABLE public.shopping_cart OWNER TO postgres;

--
-- Name: shopping_cart_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shopping_cart_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shopping_cart_id_seq OWNER TO postgres;

--
-- Name: shopping_cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shopping_cart_id_seq OWNED BY public.shopping_cart.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login character(50),
    password character(25),
    email character(55)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq OWNED BY public.users.id;


--
-- Name: informations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.informations ALTER COLUMN id SET DEFAULT nextval('public.informations_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: shopping_cart id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart ALTER COLUMN id SET DEFAULT nextval('public.shopping_cart_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: informations; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.informations VALUES (51, 'oranges                            ', 1, 10, 'user927                                                                                             ');
INSERT INTO public.informations VALUES (52, 'walnut                             ', 1, 11, 'user927                                                                                             ');
INSERT INTO public.informations VALUES (53, 'carrot                             ', 1, 3, 'user927                                                                                             ');
INSERT INTO public.informations VALUES (54, 'onion                              ', 1, 5, 'user927                                                                                             ');
INSERT INTO public.informations VALUES (55, 'garlic                             ', 1, 5, 'user801                                                                                             ');
INSERT INTO public.informations VALUES (56, 'banana                             ', 1, 10, 'user801                                                                                             ');
INSERT INTO public.informations VALUES (57, 'fish                               ', 1, 80, 'user640                                                                                             ');
INSERT INTO public.informations VALUES (58, 'milk                               ', 1, 56, 'user640                                                                                             ');
INSERT INTO public.informations VALUES (60, 'oranges                            ', 3, 30, 'newuser999                                                                                          ');
INSERT INTO public.informations VALUES (61, 'grape                              ', 2, 22, 'newuser999                                                                                          ');
INSERT INTO public.informations VALUES (62, 'ryazhenka                          ', 1, 14, 'newuser684                                                                                          ');
INSERT INTO public.informations VALUES (63, 'eggs                               ', 1, 30, 'newuser684                                                                                          ');
INSERT INTO public.informations VALUES (64, 'ryazhenka                          ', 1, 14, 'admin628                                                                                            ');
INSERT INTO public.informations VALUES (65, 'eggs                               ', 1, 30, 'admin628                                                                                            ');


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.orders VALUES (29, '2023-04-26', 'admin                                             ', 'admin628                                                                                            ', 'оформлен                 ');
INSERT INTO public.orders VALUES (22, '2023-04-24', 'user                                              ', 'user927                                                                                             ', 'Заказ отправлен          ');
INSERT INTO public.orders VALUES (25, '2023-04-25', 'user                                              ', 'user640                                                                                             ', 'оформлен                 ');
INSERT INTO public.orders VALUES (27, '2023-04-26', 'newuser                                           ', 'newuser999                                                                                          ', 'оформлен                 ');
INSERT INTO public.orders VALUES (23, '2023-04-24', 'user                                              ', 'user927                                                                                             ', 'оформлен                 ');
INSERT INTO public.orders VALUES (24, '2023-04-24', 'user                                              ', 'user801                                                                                             ', 'оформлен                 ');
INSERT INTO public.orders VALUES (28, '2023-04-26', 'newuser                                           ', 'newuser684                                                                                          ', 'оформлен                 ');


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.products VALUES (3, 'chicken meat                       ', 23, 'meat                          ', 'product03.png                 ');
INSERT INTO public.products VALUES (4, 'flounder                           ', 35, 'fish                          ', 'product04.png                 ');
INSERT INTO public.products VALUES (18, 'pineapple                          ', 15, 'fruits                        ', 'product18.png                 ');
INSERT INTO public.products VALUES (19, 'oranges                            ', 10, 'fruits                        ', 'product19.png                 ');
INSERT INTO public.products VALUES (20, 'grape                              ', 11, 'fruits                        ', 'product20.png                 ');
INSERT INTO public.products VALUES (21, 'cabbage                            ', 7, 'vegetables                    ', 'product21.png                 ');
INSERT INTO public.products VALUES (22, 'carrot                             ', 3, 'vegetables                    ', 'product22.png                 ');
INSERT INTO public.products VALUES (23, 'onion                              ', 5, 'vegetables                    ', 'product23.png                 ');
INSERT INTO public.products VALUES (24, 'garlic                             ', 5, 'vegetables                    ', 'product24.png                 ');
INSERT INTO public.products VALUES (25, 'potato                             ', 11, 'vegetables                    ', 'product25.png                 ');
INSERT INTO public.products VALUES (26, 'tomato                             ', 15, 'vegetables                    ', 'product26.png                 ');
INSERT INTO public.products VALUES (27, 'cucumber                           ', 13, 'vegetables                    ', 'product27.png                 ');
INSERT INTO public.products VALUES (28, 'peanut                             ', 7, 'nuts                          ', 'product28.png                 ');
INSERT INTO public.products VALUES (29, 'cashews                            ', 13, 'nuts                          ', 'product29.png                 ');
INSERT INTO public.products VALUES (30, 'goober                             ', 8, 'nuts                          ', 'product30.png                 ');
INSERT INTO public.products VALUES (5, 'sturgeon                           ', 41, 'fish                          ', 'product05.png                 ');
INSERT INTO public.products VALUES (16, 'banana                             ', 10, 'fruits                        ', 'product16.png                 ');
INSERT INTO public.products VALUES (1, 'meat                               ', 30, 'meat                          ', 'product01.png                 ');
INSERT INTO public.products VALUES (2, 'pork                               ', 27, 'meat                          ', 'product02.png                 ');
INSERT INTO public.products VALUES (6, 'fish                               ', 80, 'fish                          ', 'product06.png                 ');
INSERT INTO public.products VALUES (33, 'mineral water                      ', 33, 'drinks                        ', 'product33.png                 ');
INSERT INTO public.products VALUES (32, 'juices                             ', 25, 'drinks                        ', 'product32.png                 ');
INSERT INTO public.products VALUES (31, 'walnut                             ', 11, 'nuts                          ', 'product31.png                 ');
INSERT INTO public.products VALUES (7, 'milk                               ', 56, 'milk                          ', 'product07.png                 ');
INSERT INTO public.products VALUES (8, 'yogurt                             ', 16, 'milk                          ', 'product08.png                 ');
INSERT INTO public.products VALUES (9, 'ryazhenka                          ', 14, 'milk                          ', 'product09.png                 ');
INSERT INTO public.products VALUES (10, 'curd                               ', 80, 'milk                          ', 'product10.png                 ');
INSERT INTO public.products VALUES (11, 'cheese                             ', 65, 'milk                          ', 'product11.png                 ');
INSERT INTO public.products VALUES (12, 'eggs                               ', 30, 'milk                          ', 'product12.png                 ');
INSERT INTO public.products VALUES (13, 'strawberry                         ', 15, 'berries                       ', 'product13.png                 ');
INSERT INTO public.products VALUES (14, 'blueberries                        ', 22, 'berries                       ', 'product14.png                 ');
INSERT INTO public.products VALUES (15, 'raspberry                          ', 18, 'berries                       ', 'product15.png                 ');
INSERT INTO public.products VALUES (17, 'kiwi                               ', 13, 'fruits                        ', 'product17.png                 ');


--
-- Data for Name: shopping_cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.shopping_cart VALUES (59, 9, 1);
INSERT INTO public.shopping_cart VALUES (60, 12, 1);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.users VALUES (1, 'admin                                             ', 'admin                    ', 'admin@.ru                                              ');
INSERT INTO public.users VALUES (2, 'user                                              ', 'user                     ', 'user@.ru                                               ');
INSERT INTO public.users VALUES (3, 'newuser                                           ', 'newuser                  ', 'newuser@.ru                                            ');


--
-- Name: informations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.informations_id_seq', 65, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 29, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 29, true);


--
-- Name: shopping_cart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shopping_cart_id_seq', 60, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 3, true);


--
-- Name: informations informations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.informations
    ADD CONSTRAINT informations_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: shopping_cart shopping_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart
    ADD CONSTRAINT shopping_cart_pkey PRIMARY KEY (id);


--
-- Name: users user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

